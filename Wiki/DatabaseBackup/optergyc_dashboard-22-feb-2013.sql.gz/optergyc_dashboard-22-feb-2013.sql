-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 22, 2013 at 09:45 AM
-- Server version: 5.1.37
-- PHP Version: 5.2.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `optergyc_dashboard`
--

-- --------------------------------------------------------

--
-- Table structure for table `aa_job`
--

CREATE TABLE `aa_job` (
  `trans_date` date NOT NULL,
  `project` varchar(5) NOT NULL,
  `branch` int(11) NOT NULL,
  `manager` varchar(20) NOT NULL,
  `type` varchar(5) NOT NULL,
  `cost` double NOT NULL,
  `doc_type` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `acn_job`
--

CREATE TABLE `acn_job` (
  `trans_date` date NOT NULL,
  `project` varchar(5) NOT NULL,
  `branch` int(11) NOT NULL,
  `manager` varchar(20) NOT NULL,
  `type` varchar(5) NOT NULL,
  `cost` double NOT NULL,
  `doc_type` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `acs_job`
--

CREATE TABLE `acs_job` (
  `trans_date` date NOT NULL,
  `project` varchar(5) NOT NULL,
  `branch` int(11) NOT NULL,
  `manager` varchar(20) NOT NULL,
  `type` varchar(5) NOT NULL,
  `cost` double NOT NULL,
  `doc_type` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `acv_job`
--

CREATE TABLE `acv_job` (
  `trans_date` date NOT NULL,
  `project` varchar(5) NOT NULL,
  `branch` int(11) NOT NULL,
  `manager` varchar(20) NOT NULL,
  `type` varchar(5) NOT NULL,
  `cost` double NOT NULL,
  `doc_type` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `acw_job`
--

CREATE TABLE `acw_job` (
  `trans_date` date NOT NULL,
  `project` varchar(5) NOT NULL,
  `branch` int(11) NOT NULL,
  `manager` varchar(20) NOT NULL,
  `type` varchar(5) NOT NULL,
  `cost` double NOT NULL,
  `doc_type` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `check_date`
--

CREATE TABLE `check_date` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_table`
--

CREATE TABLE `dashboard_table` (
  `project` varchar(10) NOT NULL,
  `manager` varchar(30) NOT NULL,
  `revenue` double NOT NULL,
  `nominal` double NOT NULL,
  `acv` double NOT NULL,
  `acv_n` double NOT NULL,
  `acn` double NOT NULL,
  `acn_n` double NOT NULL,
  `acs` double NOT NULL,
  `acs_n` double NOT NULL,
  `acw` double NOT NULL,
  `acw_n` double NOT NULL,
  `opt` double NOT NULL,
  `opt_n` double NOT NULL,
  `ee_margin` double NOT NULL,
  `over_due` double NOT NULL,
  `a_ee_margin` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_table_one`
--

CREATE TABLE `dashboard_table_one` (
  `project` varchar(10) NOT NULL,
  `manager` varchar(30) NOT NULL,
  `branch` varchar(15) NOT NULL,
  `revenue` double NOT NULL,
  `nominal` double NOT NULL,
  `acv` double NOT NULL,
  `acv_n` double NOT NULL,
  `acn` double NOT NULL,
  `acn_n` double NOT NULL,
  `acs` double NOT NULL,
  `acs_n` double NOT NULL,
  `acw` double NOT NULL,
  `acw_n` double NOT NULL,
  `opt` double NOT NULL,
  `opt_n` double NOT NULL,
  `ee_margin` double NOT NULL,
  `over_due` double NOT NULL,
  `a_ee_margin` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_table_six`
--

CREATE TABLE `dashboard_table_six` (
  `project` varchar(10) NOT NULL,
  `manager` varchar(30) NOT NULL,
  `branch` varchar(15) NOT NULL,
  `revenue` double NOT NULL,
  `nominal` double NOT NULL,
  `acv` double NOT NULL,
  `acv_n` double NOT NULL,
  `acn` double NOT NULL,
  `acn_n` double NOT NULL,
  `acs` double NOT NULL,
  `acs_n` double NOT NULL,
  `acw` double NOT NULL,
  `acw_n` double NOT NULL,
  `opt` double NOT NULL,
  `opt_n` double NOT NULL,
  `ee_margin` double NOT NULL,
  `over_due` double NOT NULL,
  `a_ee_margin` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_table_twelve`
--

CREATE TABLE `dashboard_table_twelve` (
  `project` varchar(10) NOT NULL,
  `manager` varchar(30) NOT NULL,
  `branch` varchar(15) NOT NULL,
  `revenue` double NOT NULL,
  `nominal` double NOT NULL,
  `acv` double NOT NULL,
  `acv_n` double NOT NULL,
  `acn` double NOT NULL,
  `acn_n` double NOT NULL,
  `acs` double NOT NULL,
  `acs_n` double NOT NULL,
  `acw` double NOT NULL,
  `acw_n` double NOT NULL,
  `opt` double NOT NULL,
  `opt_n` double NOT NULL,
  `ee_margin` double NOT NULL,
  `over_due` double NOT NULL,
  `a_ee_margin` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `filtered_data`
--

CREATE TABLE `filtered_data` (
  `project` varchar(15) NOT NULL,
  `manager` varchar(30) NOT NULL,
  `branch` varchar(15) NOT NULL,
  `revenue` double NOT NULL,
  `cost` double NOT NULL,
  `acn` double NOT NULL,
  `acn_n` double NOT NULL,
  `acs` double NOT NULL,
  `acs_n` double NOT NULL,
  `acv` double NOT NULL,
  `acv_n` double NOT NULL,
  `acw` double NOT NULL,
  `acw_n` double NOT NULL,
  `opt` double NOT NULL,
  `opt_n` double NOT NULL,
  `over_due` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `filtered_data_six`
--

CREATE TABLE `filtered_data_six` (
  `project` varchar(15) NOT NULL,
  `manager` varchar(30) NOT NULL,
  `branch` varchar(15) NOT NULL,
  `revenue` double NOT NULL,
  `cost` double NOT NULL,
  `acn` double NOT NULL,
  `acn_n` double NOT NULL,
  `acs` double NOT NULL,
  `acs_n` double NOT NULL,
  `acv` double NOT NULL,
  `acv_n` double NOT NULL,
  `acw` double NOT NULL,
  `acw_n` double NOT NULL,
  `opt` double NOT NULL,
  `opt_n` double NOT NULL,
  `over_due` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `filtered_data_twelve`
--

CREATE TABLE `filtered_data_twelve` (
  `project` varchar(15) NOT NULL,
  `manager` varchar(30) NOT NULL,
  `branch` varchar(15) NOT NULL,
  `revenue` double NOT NULL,
  `cost` double NOT NULL,
  `acn` double NOT NULL,
  `acn_n` double NOT NULL,
  `acs` double NOT NULL,
  `acs_n` double NOT NULL,
  `acv` double NOT NULL,
  `acv_n` double NOT NULL,
  `acw` double NOT NULL,
  `acw_n` double NOT NULL,
  `opt` double NOT NULL,
  `opt_n` double NOT NULL,
  `over_due` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `names`
--

CREATE TABLE `names` (
  `manager` varchar(35) NOT NULL,
  `manager_name` varchar(35) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `opt_job`
--

CREATE TABLE `opt_job` (
  `trans_date` date NOT NULL,
  `project` varchar(5) NOT NULL,
  `branch` int(11) NOT NULL,
  `manager` varchar(20) NOT NULL,
  `type` varchar(5) NOT NULL,
  `cost` double NOT NULL,
  `doc_type` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `over_due`
--

CREATE TABLE `over_due` (
  `trans_date` date NOT NULL,
  `project` varchar(20) NOT NULL,
  `invoice` varchar(20) NOT NULL,
  `amount` double NOT NULL,
  `branch` varchar(30) NOT NULL,
  `manager` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `branch` varchar(5) NOT NULL,
  `branch_name` varchar(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Login` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `lockout` int(1) NOT NULL DEFAULT '0',
  `lockouttime` varchar(20) NOT NULL,
  `unlocktime` varchar(20) NOT NULL,
  `admin` int(1) NOT NULL DEFAULT '0',
  `banned` int(1) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;
